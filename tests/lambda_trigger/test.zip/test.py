def lambda_handler(event, context):
    test_event = event["test_event"]
    print(f'Test event: {test_event}')
